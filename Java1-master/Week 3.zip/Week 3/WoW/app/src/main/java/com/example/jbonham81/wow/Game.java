package com.example.jbonham81.wow;

/**
 * Created by jbonham81 on 11/9/14.
 */
public class Game {

    public static Game newGame(String _name, String _release, String _lvlCap, String _features) {

        Game game = new Game();
        game.setName(_name);
        game.setRelease(_release);
        game.setLvlCap(_lvlCap);
        game.setFeatures(_features);
        return game;
    }

    private String name;
    private String release;
    private String lvlCap;
    private String features;

//    public Game(){
//
//    }

    public Game() {
        name = "";
        release = "";
        lvlCap = "";
        features = "";
    }

    public Game(String _name, String _release, String _lvlCap, String _features) {
        name = _name;
        release = _release;
        lvlCap = _lvlCap;
        features = _features;
    }




    public String getName() {
        return name;
    }

    public String getRelease() {
        return release;
    }

    public String getLvlCap() {
        return lvlCap;
    }

    public String getFeatures() {
        return features;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public void setLvlCap(String lvlCap) {
        this.lvlCap = lvlCap;
    }

    public void setFeatures(String features) {
        this.features = features;
    }
}
