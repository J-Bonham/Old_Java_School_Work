

package com.example.jbonham81.wow;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

import java.util.HashMap;


public class MyActivity extends Activity {

        ListView list;
        Spinner spinner;
        ArrayList<Game> game;
        ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        list = (ListView) findViewById(R.id.listofgames);
        spinner = (Spinner) findViewById(R.id.spinner);
        game = new ArrayList<Game>();

        //Create Game items using custom Game class
        game.add(new Game("Warcraft", "November 2004", "60", "Original Release"));
        game.add(new Game("The Burning Crusade", "2007", "70", "New Races: Draenei and Blood Elves"));
        game.add(new Game("Wrath of the Lich King", "2008", "80", "New Class: Death Knight"));
        game.add(new Game("Cataclysm", "2010", "85", "New Races: Goblin and Worgen"));
        game.add(new Game("Mists of Panderia", "2012", "90", "New Race: Panderen"));
        game.add(new Game("Warlords of Draenor", "2014", "100", "Garrison Building"));

//        ArrayList<String> gameList = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.games)));
//        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,gameList);
//
//        spinner.setAdapter(adapter);

        createAdapterViews();

    }

    private void createAdapterViews() {


        final String name = "name";
        final String release = "release";
        final String level = "level";
        final String hmFeature = "feature";



        final ArrayList<HashMap<String, String>> info = new ArrayList<HashMap<String, String>>();

        for(Game i: game) {

            HashMap<String, String> map = new HashMap<String, String>();
            map.put(name, i.getName());
            map.put(release, i.getRelease());
            map.put(level, i.getLvlCap());
            map.put(hmFeature, i.getFeatures());

            info.add(map);

        }

        String[] keys = new String[] {
                name
        };

        int [] views = new int[] {
                R.id.gametext,

        };




        SimpleAdapter vAdapter = new SimpleAdapter(this, info, R.layout.layout, keys, views);

        list.setAdapter(vAdapter);
        spinner.setAdapter(vAdapter);



    }







    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.my, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
