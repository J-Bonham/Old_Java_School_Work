// Jeremiah Bonham
// Java 1 Week 4 1411
//
// API Key for quick usage without looking up
// http://www.omdbapi.com/?t= |search string| &y=&plot=short&r=json
//

package com.example.jbonham81.week4;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class MainActivity extends Activity implements View.OnClickListener {

    String TAG = "-----------------Testing----------------";
    Button search;
    EditText userInput;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = (Button) findViewById(R.id.searchbutton);
        search.setOnClickListener(this);

        userInput = (EditText) findViewById(R.id.userinput);
        text = (TextView) findViewById(R.id.text);

    }

    //onClick
    @Override
    public void onClick(View view) {
        getData();
    }

    private void updateDisplay(Movie movie) {

        System.out.println("-----------Reaching Update Method---------------");

        ((TextView) findViewById(R.id.text)).setText(movie.getTitle());



    }

    private void getData() {

        ConnectivityCheck connectivity = new ConnectivityCheck(getApplicationContext());

        boolean isConnecting = connectivity.isConnected();
        if (isConnecting) {
            System.out.println("------------------Connected------------------");

            String input = userInput.getText().toString();

            try {

                String baseURL = "http://www.omdbapi.com/?t=";
                String endUrl =  "&y=&plot=short&r=json";

                String search = (input);
                String encodedString = URLEncoder.encode(search, "UTF-8");
                URL queryURL = new URL(baseURL + encodedString + endUrl);

                new GetMoviesTask().execute(queryURL);

            } catch (Exception e) {
                Log.e(TAG, "Invalid query: " + input);
            }

        } else {
            System.out.println("------------------Not Connected------------------");
        }
    }


    private class GetMoviesTask extends AsyncTask<URL, Integer, JSONObject> {
        @Override
        protected JSONObject doInBackground(URL... urls) {
            String jsonString = "";

            for (URL queryURL : urls) {
                try {
                    URLConnection conn = queryURL.openConnection();
                    jsonString = IOUtils.toString(conn.getInputStream());
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "Could not establish URLConnection to " + queryURL.toString());
                }
                System.out.println(jsonString);
            }

            JSONObject apiData = null;

            try {
                apiData = new JSONObject(jsonString);


                System.out.println("------------------" + apiData);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            System.out.println("---------getting to api---------" + apiData);
            return apiData;

        }

        protected void onPostExecute(JSONObject apiData) {
            Movie result = new Movie(apiData);
            updateDisplay(result);
        }
    }






}