// Jeremiah Bonham
// Java 1 Week 4 1411
//
// API Key for quick usage without looking up
// http://www.omdbapi.com/?t= |search string| &y=&plot=short&r=json
//

package com.example.jbonham81.week4;

import android.util.Log;
import org.json.JSONObject;

/**
 * Created by jbonham81 on 11/18/14.
 */

public class Movie {

    String TAG = "----------------- Testing Movie ----------------";

    private String mTitle;

    public Movie(){}

    public Movie(String title){
        mTitle = title;


    }

    public Movie(JSONObject movieData){
        try {
            mTitle = movieData.getString("Title");

        } catch (Exception e) {
            Log.e(TAG, "Error updating display");

        }
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }



 }

